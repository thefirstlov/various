package com.gec.vaccinum;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VaccinumApplicationTests {

    @Test
    void contextLoads() {
    }

}
