'use strict';
$(document).ready(function () {

    new Dropzone("#my-awesome-dropzone", {});

});