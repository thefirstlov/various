package com.gec.vaccinum;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VaccinumApplication {

    public static void main(String[] args) {
        SpringApplication.run(VaccinumApplication.class, args);
    }

}
