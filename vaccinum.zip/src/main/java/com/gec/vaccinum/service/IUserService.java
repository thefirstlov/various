package com.gec.vaccinum.service;

import com.gec.vaccinum.entity.User;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 用户 服务类
 * </p>
 *
 * @author jerry
 * @since 2023-06-14
 */
public interface IUserService extends IService<User> {

}
