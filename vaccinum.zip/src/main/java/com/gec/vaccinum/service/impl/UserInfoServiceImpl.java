package com.gec.vaccinum.service.impl;

import com.gec.vaccinum.entity.UserInfo;
import com.gec.vaccinum.mapper.UserInfoMapper;
import com.gec.vaccinum.service.IUserInfoService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 用户信息 服务实现类
 * </p>
 *
 * @author jerry
 * @since 2023-06-18
 */
@Service
public class UserInfoServiceImpl extends ServiceImpl<UserInfoMapper, UserInfo> implements IUserInfoService {

}
