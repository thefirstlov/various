package com.gec.vaccinum.service;

import com.gec.vaccinum.entity.VaccinumType;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 疫苗类型 服务类
 * </p>
 *
 * @author jerry
 * @since 2023-06-14
 */
public interface IVaccinumTypeService extends IService<VaccinumType> {

}
