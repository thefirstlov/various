package com.gec.vaccinum.service.impl;

import cn.hutool.extra.qrcode.QrCodeUtil;
import cn.hutool.extra.qrcode.QrConfig;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gec.vaccinum.entity.UserInfo;
import com.gec.vaccinum.service.IUserInfoService;
import com.gec.vaccinum.service.QRService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import java.awt.*;
import java.io.IOException;

@Service
public class QRServiceImpl implements QRService {
    //从ioc容器中获取二维码配置的对象
    @Resource
    QrConfig qrconig;

    @Autowired
    IUserInfoService infoService;
    // json格式的工具类
    ObjectMapper jsonTool = new ObjectMapper();

    @Override
    public void generateStream(Long userid, HttpServletResponse response) throws IOException {
        // 查询用户的信息
        UserInfo userInfo = infoService.getById(userid);
        // 判断-并设置当前通行码的方格颜色
        if (userInfo.getStatus() == 0) {//绿码
            qrconig.setForeColor(Color.green.getRGB());
        } else if (userInfo.getStatus() == 1) {//黄码
            qrconig.setForeColor(Color.yellow.getRGB());
        } else if (userInfo.getStatus() == 2) {//红码
            qrconig.setForeColor(Color.red.getRGB());
        }
        // json格式的用户信息
        String valueAsString = jsonTool.writeValueAsString(userInfo);
        //使用QrCodeUtil工具类generate生成二维码的图片流
        QrCodeUtil.generate(valueAsString, qrconig, "png", response.getOutputStream());
    }
}