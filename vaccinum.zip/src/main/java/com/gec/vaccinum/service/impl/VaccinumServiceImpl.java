package com.gec.vaccinum.service.impl;

import com.gec.vaccinum.entity.Vaccinum;
import com.gec.vaccinum.mapper.VaccinumMapper;
import com.gec.vaccinum.service.IVaccinumService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 疫苗 服务实现类
 * </p>
 *
 * @author jerry
 * @since 2023-06-14
 */
@Service
public class VaccinumServiceImpl extends ServiceImpl<VaccinumMapper, Vaccinum> implements IVaccinumService {

}
