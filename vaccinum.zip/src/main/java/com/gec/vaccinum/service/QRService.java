package com.gec.vaccinum.service;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

//二维码生成的策略接口
public interface QRService {
    //根据content（二维码中存储的信息）、HttpServletResponse（http的响应对象）
    public void generateStream(Long userid, HttpServletResponse response) throws IOException;
}

