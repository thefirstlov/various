package com.gec.vaccinum.service.impl;

import com.gec.vaccinum.entity.VaccinumType;
import com.gec.vaccinum.mapper.VaccinumTypeMapper;
import com.gec.vaccinum.service.IVaccinumTypeService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 疫苗类型 服务实现类
 * </p>
 *
 * @author jerry
 * @since 2023-06-14
 */
@Service
public class VaccinumTypeServiceImpl extends ServiceImpl<VaccinumTypeMapper, VaccinumType> implements IVaccinumTypeService {

}
