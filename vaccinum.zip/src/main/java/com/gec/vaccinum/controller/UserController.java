package com.gec.vaccinum.controller;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.gec.vaccinum.entity.User;
import com.gec.vaccinum.entity.UserInfo;
import com.gec.vaccinum.service.IUserInfoService;
import com.gec.vaccinum.service.IUserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * <p>
 * 用户 前端控制器
 * </p>
 *
 * @author jerry
 * @since 2023-06-14
 */
@Controller
@RequestMapping("/user")
public class UserController {

    //Autowired获取IUserService的对象
    @Autowired
    IUserService userService;
    @Autowired
    IUserInfoService infoService;



    @RequestMapping("register")
    public String register(String name, String phone, String password, MultipartFile file) throws  Exception{
        int  i = 0;
        QueryWrapper<User> queryWrapper = new QueryWrapper<User>().eq("phone",phone);
        User u = new User();
        // 上传文件
        String fileName = upload(file);
        if (fileName != null && !fileName.equals("")) {
            u.setImage(fileName);
        }

        i = userService.count(queryWrapper);
        System.out.println(i);
        if(i != 0){
            return "register";
        }else{

            List<User> list = new ArrayList<User>();

            u.setName(name);
            u.setPhone(phone);
            u.setPassword(password);
            System.out.println(u.getPassword());

            list.add(u);

            boolean b = userService.saveOrUpdateBatch(list);

            if(b){
                return "login";
            }else{
                return "register";

            }

        }
    }

    //    定义一个文件存储的本地目录
    public String filePath = "E:\\壁纸\\";

    //定义一个删除用户数据的请求接口
    @RequestMapping("delete")
    public String delete(Long id) throws IOException {
        //  通过调用业务层根据主键来进行删除
        userService.removeById(id);
        // 操作成功，则跳转查询新的数据
        return "redirect:/user/list";
    }

    //定义一个修改用户数据的请求接口
    @RequestMapping("update")
    public String update(User user, MultipartFile file, HttpServletRequest request) throws IOException {
        // 上传文件
        String fileName = upload(file);
        if (fileName != null && !fileName.equals("")) {
            user.setImage(fileName);
        }
        //  通过调用业务层来实现修改的业务功能【根据主键来进行修改】
        boolean update = userService.updateById(user);
        //  判断
        if (update) {
            //操作成功，则跳转查询新的数据
            return "redirect:/user/list";
        } else {
            //跳转到修改页面
            return "redirect:/user/toUpdatePage?id=" + user.getId();//  重定向
        }
    }

    //定义一个跳转到用户修改的页面的请求接口
    @RequestMapping("toUpdatePage")
    public String toUpdatePage(Long id, HttpServletRequest request) throws IOException {
        //  通过调用业务层来查询user
        User user = userService.getById(id);
        //保存添加的数据到作用域，跳转页面显示
        request.setAttribute("user", user);
        //跳转页面userUpdate.jsp
        return "userUpdate";//  跳转页面userUpdate   --> /跳转页面userUpdate.jsp
    }

    //提供一个文件上传的方法
    public String upload(MultipartFile file) throws IOException {
        //1、随机数  2、时间戳  3、UUID
        //  ui-divya.jpg  --- > SDFDSFDSFSD132435SD2FDS.jpg
        String uuid = UUID.randomUUID().toString();
        //getOriginalFilename--文件名
        String fileName = file.getOriginalFilename();
        //后缀
        String subfix = fileName.substring(fileName.lastIndexOf("."));
        //拼接uuid和后缀名
        fileName = uuid + subfix;
        System.out.println("文件名：" + fileName);
        //文件上传
        file.transferTo(new File(filePath + fileName));
        // 返回文件名
        return fileName;
    }

    //定义一个添加用户数据的请求接口
    @RequestMapping("insert")
    public String insert(User user, MultipartFile file, HttpServletRequest request) throws IOException {
        // 上传文件

        QueryWrapper<User> queryWrapper = new QueryWrapper<User>().eq("phone", user.getPhone());
        int i = userService.count(queryWrapper);
        if (i != 0) {
            request.setAttribute("user", user);
            return "userInsert";
        } else {
            String fileName = upload(file);
            if (fileName != null && !fileName.equals("")) {
                user.setImage(fileName);
            }
            //  通过调用业务层来实现添加的业务功能
            boolean save = userService.save(user);
            // 考核点：可以先做一个查询判断，判断数据库中有没有该手机号
            //  判断
            if (save) {
                //操作成功，则跳转查询新的数据
                return "redirect:/user/list";
            } else {
                //失败，保存添加的数据到作用域（回显），则跳转回到添加页面
                request.setAttribute("user", user);
                //跳转页面userInsert.jsp
                return "userInsert";//  跳转页面userInsert   --> /跳转页面userInsert.jsp
            }
        }
    }

    // http://localhost:8080/user/loginUser?phone=12345678901&password=123
    //定义一个请求接口来进行登录查询【成功-首页、失败-登录页面】
    @RequestMapping("loginUser")
    public String loginUser(String phone, String password, HttpServletRequest request) {
        //定义条件构造器   手机号、密码
        QueryWrapper wrapper = new QueryWrapper<User>()
                .eq("phone", phone)
                .eq("password", password);
        // 登录查询操作
        User user = userService.getOne(wrapper);
        // 判断-成功、失败   通过视图解析器来跳转页面
        if (user != null) {
            String message = "";

            message = "上传数据成功！";

            request.getSession().setAttribute("mes", message);

            return "index";// index  --> /index.jsp
        } else {
            return "login";// login  --> /login.jsp
        }
    }

    // http://localhost:8080/user/list
    //定义一个请求接口来查询user信息
    @RequestMapping("list")
    public String list(HttpServletRequest request) {
        // 如何查询user的数据？
        List<User> userList = userService.list();
        userList.forEach(user -> {
            UserInfo userInfo =infoService.getById(user.getId());
            user.setUserInfo(userInfo);
        });
        //通过请求作用域保存数据
        request.setAttribute("list", userList);
        //跳转页面userIndex.jsp
        return "userIndex";//  userIndex   --> /userIndex.jsp
    }

    }

