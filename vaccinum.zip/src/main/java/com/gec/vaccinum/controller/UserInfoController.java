package com.gec.vaccinum.controller;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * 用户信息 前端控制器
 * </p>
 *
 * @author jerry
 * @since 2023-06-18
 */
@RestController
@RequestMapping("/gec.vaccinum/user-info")
public class UserInfoController {

}
