package com.gec.vaccinum.controller;


import com.gec.vaccinum.entity.User;
import com.gec.vaccinum.entity.Vaccinum;
import com.gec.vaccinum.entity.VaccinumType;
import com.gec.vaccinum.service.IVaccinumService;
import com.gec.vaccinum.service.IVaccinumTypeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.List;

/**
 * <p>
 * 疫苗 前端控制器
 * </p>
 *
 * @author jerry
 * @since 2023-06-14
 */
@Controller
@RequestMapping("/vaccinum")
public class VaccinumController {

    //vaccinum的业务层对象
    @Autowired
    IVaccinumService vaccinumService;
    //VaccinumType的业务层对象
    @Autowired
    IVaccinumTypeService typeService;

    //定义一个修改用户数据的请求接口
    @RequestMapping("update")
    public String update(Vaccinum vaccinum, HttpServletRequest request) throws IOException {
        // 上传文件

        //  通过调用业务层来实现修改的业务功能【根据主键来进行修改】
        boolean update = vaccinumService.updateById(vaccinum);
        //  判断
        if (update) {
            //操作成功，则跳转查询新的数据
            return "redirect:/vaccinum/list";
        } else {
            //跳转到修改页面
            return "redirect:/vaccinum/toUpdatePage?id=" + vaccinum.getId();//  重定向
        }
    }
    //定义一个跳转到vaccinum修改的页面的请求接口
    @RequestMapping("toUpdatePage")
    public String toUpdatePage(Long id, HttpServletRequest request) throws IOException {
        //  通过调用业务层来查询vaccinum
        Vaccinum vaccinum = vaccinumService.getById(id);
        // 查询VaccinumType的数据
        List<VaccinumType> typeList = typeService.list();
        //通过请求作用域保存数据
        request.setAttribute("typeList", typeList);
        //保存添加的数据到作用域，跳转页面显示
        request.setAttribute("vaccinum", vaccinum);
        //跳转页面vaccinumUpdate.jsp
        return "vaccinumUpdate";//  vaccinumUpdate.jsp
    }

    //定义一个请求接口来跳转到新增疫苗的页面
    @RequestMapping("toInsertPage")
    public String toInsertPage(HttpServletRequest request) {
        // 如何查询user的数据？
        List<VaccinumType> typeList = typeService.list();
        //通过请求作用域保存数据
        request.setAttribute("typeList", typeList);
        //跳转页面vaccinumInsert.jsp
        return "vaccinumInsert";// vaccinumInsert.jsp

    }

    //定义一个请求接口来查询vaccinum信息
    @RequestMapping("list")
    public String list(HttpServletRequest request) {
        // 如何查询user的数据？
        List<Vaccinum> vaccinumList = vaccinumService.list();
        // 遍历疫苗集合forEach，然后根据分类id查询分类信息，把分类名赋值到疫苗对象中
        vaccinumList.forEach(entity -> {
            //根据id查询分类、把信息赋值entity
            VaccinumType type = typeService.getById(entity.getType());
            entity.setTypeName(type.getName());
        });
        //通过请求作用域保存数据
        request.setAttribute("list", vaccinumList);
        //跳转页面定义一个请求接口来查询vaccinum信息Index.jsp
        return "vaccinumIndex";//  vaccinumIndex   --> /vaccinumIndex.jsp
    }
    //定义一个添加用户数据的请求接口
    @RequestMapping("insert")
    public String insert(Vaccinum vaccinum, MultipartFile file, HttpServletRequest request) throws IOException {
  /*  // 上传文件
    String fileName = upload(file);
    if (fileName != null && !fileName.equals("")) {
        user.setImage(fileName);
    }*/
        //  通过调用业务层来实现添加的业务功能
        boolean save = vaccinumService.save(vaccinum);
        // 考核点：可以先做一个查询判断，判断数据库中有没有该手机号
        //  判断
        if (save) {
            //操作成功，则跳转查询新的数据
            return "redirect:/vaccinum/list";
        } else {
            //失败，保存添加的数据到作用域（回显），则跳转回到添加页面
            request.setAttribute("vaccinum", vaccinum);
            //跳转页面userInsert.jsp
            return "vaccinumInsert";//  跳转页面userInsert   --> /跳转页面userInsert.jsp
        }
    }
    @RequestMapping("delete")
    public String delete(Long id) throws IOException {
        //  通过调用业务层根据主键来进行删除
        vaccinumService.removeById(id);
        // 操作成功，则跳转查询新的数据
        return "redirect:/vaccinum/list";
    }

}
