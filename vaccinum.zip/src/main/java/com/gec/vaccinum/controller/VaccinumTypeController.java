package com.gec.vaccinum.controller;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.gec.vaccinum.entity.User;
import com.gec.vaccinum.entity.VaccinumType;
import com.gec.vaccinum.service.IUserService;
import com.gec.vaccinum.service.IVaccinumService;
import com.gec.vaccinum.service.IVaccinumTypeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.UUID;

/**
 * <p>
 * 用户 前端控制器
 * </p>
 *
 * @author jerry
 * @since 2023-06-14
 */
@Controller
@RequestMapping("/vaccinumType")
public class VaccinumTypeController {



    //Autowired获取IUserService的对象
    @Autowired
    IVaccinumTypeService vaccinumTypeService;

    //定义一个删除用户数据的请求接口
    @RequestMapping("delete")
    public String delete(Long id) throws IOException {
        //  通过调用业务层根据主键来进行删除
        vaccinumTypeService.removeById(id);
        // 操作成功，则跳转查询新的数据
        return "redirect:/vaccinumType/list";
    }

    //定义一个修改用户数据的请求接口
    @RequestMapping("update")
    public String update(VaccinumType vaccinumType, HttpServletRequest request) throws IOException {
        // 上传文件

        //  通过调用业务层来实现修改的业务功能【根据主键来进行修改】
        boolean update = vaccinumTypeService.updateById(vaccinumType);
        //  判断
        if (update) {
            //操作成功，则跳转查询新的数据
            return "redirect:/vaccinumType/list";
        } else {
            //跳转到修改页面
            return "redirect:/vaccinumType/toUpdatePage?id=" + vaccinumType.getId();//  重定向
        }
    }

    //定义一个跳转到用户修改的页面的请求接口
    @RequestMapping("toUpdatePage")
    public String toUpdatePage(Long id, HttpServletRequest request) throws IOException {
        //  通过调用业务层来查询user
        VaccinumType vaccinumType = vaccinumTypeService.getById(id);

        //保存添加的数据到作用域，跳转页面显示
        request.setAttribute("vaccinumType", vaccinumType);

        //跳转页面userUpdate.jsp
        return "vaccinumTypeUpdate";//  跳转页面userUpdate   --> /跳转页面userUpdate.jsp
    }


    //定义一个添加用户数据的请求接口
    @RequestMapping("insert")
    public String insert(VaccinumType vaccinumType, HttpServletRequest request) throws IOException {
        // 上传文件

        //  通过调用业务层来实现添加的业务功能
        boolean save = vaccinumTypeService.save(vaccinumType);
        // 考核点：可以先做一个查询判断，判断数据库中有没有该手机号
        //  判断
        if (save) {
            //操作成功，则跳转查询新的数据
            return "redirect:/vaccinumType/list";
        } else {
            //失败，保存添加的数据到作用域（回显），则跳转回到添加页面
            request.setAttribute("vaccinumType", vaccinumType);
            //跳转页面userInsert.jsp
            return "vaccinumTypeInsert";//  跳转页面userInsert   --> /跳转页面userInsert.jsp
        }
    }


    // http://localhost:8080/user/loginUser?phone=12345678901&password=123
    //定义一个请求接口来进行登录查询【成功-首页、失败-登录页面】

    // http://localhost:8080/user/list
    //定义一个请求接口来查询user信息
    @RequestMapping("list")
    public String list(HttpServletRequest request) {
        // 如何查询user的数据？
        List<VaccinumType> vaccinumTypeList = vaccinumTypeService.list();
        //通过请求作用域保存数据
        request.setAttribute("list", vaccinumTypeList);
        //跳转页面userIndex.jsp
        return "vaccinumTypeIndex";//  userIndex   --> /userIndex.jsp
    }

}
