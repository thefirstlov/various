package com.gec.vaccinum.entity;

import java.io.Serializable;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * <p>
 * 疫苗类型
 * </p>
 *
 * @author jerry
 * @since 2023-06-14
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class VaccinumType implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * id    -- AUTO表示为自增策略
     */
    @TableId(type = IdType.AUTO)
    private Long id;

    /**
     * 疫苗类型
     */
    private String name;

    /**
     * 描述
     */
    private String remark;

    @TableField(exist = false)
    private String typeName;


}
